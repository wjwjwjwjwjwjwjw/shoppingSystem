package shop;

public class Main {//主函数入口

    public static void main(String[] args) {
        ShoppingSystem shoppingSystem = new ShoppingSystem();
        shoppingSystem.start();//进入初始菜单界面
    }
}
